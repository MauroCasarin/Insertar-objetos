// DEPRECATED: This app now uses pure Vanilla JS (index.html + app.js) to avoid in-browser Babel errors.
// Please refer to app.js for logic.